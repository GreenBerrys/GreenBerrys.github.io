# todoapp

Zum starten die Datei **todo.html** starten.
Die Daten werden im Browsercache gespeichert.

